create unique index EVENT_ID_UINDEX
    on EVENT (ID);

